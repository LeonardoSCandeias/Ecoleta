// JavaScript do Ecoleta.
// As funcionalidades interativas poderão ser adicionadas aqui.
